<?php 
//require_once("clases/AccesoDatos.php");
require_once("funciones.php");

GuardarImagen('testImagen');

?>